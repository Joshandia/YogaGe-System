<div class="container-fluid px-4">
    <h1 class="mt-4">Welcome to YogaGe</h1>
    <div class="row">
        <h3 class="mt-4">My YogaGe</h3>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-indigo-light text-white mb-4">
                <div class="card-body">List My Course</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= $this->Url->build('/Enrolments') ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-indigo-light text-white mb-4">
                <div class="card-body">List My Answer Sheet</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= $this->Url->build('/Answer-sheets') ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-indigo-light text-white mb-4">
                <div class="card-body">List My Certification</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?= $this->Url->build('/Awards') ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

