<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\AnswerSheet $answerSheet
 * @var \Cake\Collection\CollectionInterface|string[] $students
 * @var \Cake\Collection\CollectionInterface|string[] $questions
 * @var \App\Model\Entity\AnswerSheet[]|\Cake\Collection\CollectionInterface $question
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h6><?='Student ID: ' . $answerSheet->student_id ?></h6>
        </div>
    </aside>

    <div class="column-responsive column-80">
        <div class="answerSheets form content">
            <?= $this->Form->create($answerSheet) ?>
            <fieldset>
                <legend><?='Question : ' . $question?></legend>
                <?php
                echo $this->Form->control('answer');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
