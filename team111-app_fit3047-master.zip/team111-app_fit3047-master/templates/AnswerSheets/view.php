<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\AnswerSheet $answerSheet
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="answerSheets view content">
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Answer') ?></th>
                    <td><?= h($answerSheet->answer) ?></td>
                </tr>
                <tr>
                    <th><?= __('Student') ?></th>
                    <td><?= $answerSheet->has('student') ? $this->Html->link($answerSheet->student->id, ['controller' => 'Students', 'action' => 'view', $answerSheet->student->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Question') ?></th>
                    <td><?= $answerSheet->has('question') ? $this->Html->link($answerSheet->question->question, ['controller' => 'Questions', 'action' => 'view', $answerSheet->question->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Status') ?></th>
                    <td><?= h($answerSheet->status) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
