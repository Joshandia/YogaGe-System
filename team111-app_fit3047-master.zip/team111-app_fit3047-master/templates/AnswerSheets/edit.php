<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\AnswerSheet $answerSheet
 * @var string[]|\Cake\Collection\CollectionInterface $students
 * @var string[]|\Cake\Collection\CollectionInterface $questions
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $answerSheet->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $answerSheet->id), 'class' => 'btn btn-dark']
            ) ?>
            <?= $this->Html->link(__('List Answer Sheets'), ['action' => 'index'], ['class' => 'btn btn-dark']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="answerSheets form content">
            <?= $this->Form->create($answerSheet) ?>
            <fieldset>
                <legend><?= __('Edit Answer Sheet') ?></legend>
                <?php
                echo $this->Form->control('answer');
                echo $this->Form->control('student_id', ['options' => $students]);
                echo $this->Form->control('question_id', ['options' => $questions]);
                echo $this->Form->control('status',['options' =>['Pass'=>'Pass','Fail'=>'Fail']]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-primary']) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
