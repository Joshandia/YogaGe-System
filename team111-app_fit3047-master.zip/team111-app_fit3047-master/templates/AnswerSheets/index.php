<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\AnswerSheet[]|\Cake\Collection\CollectionInterface $answerSheets
 * @var \App\Model\Entity\AnswerSheet $checkStudent
 * @var \App\Model\Entity\AnswerSheet $lessonTable
 * @var \App\Model\Entity\AnswerSheet $courseTable
 */
?>
<div class="answerSheets index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?=$checkStudent == 1 ? __('My Answer Sheet') : __('Answer Sheet') ?></h1>
        <?= $checkStudent == 1 ? '' : $this->Html->link(__('New Answer Sheet'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    </div>

    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
            <tr>
                <?php if ($checkStudent == 1): ?>
                    <th><?= $this->Paginator->sort('Course') ?></th>
                    <th><?= $this->Paginator->sort('Lesson') ?></th>
                    <th><?= $this->Paginator->sort('Question Description') ?></th>
                    <th><?= $this->Paginator->sort('Your Answer') ?></th>
                <?php else: ?>
                    <th><?= $this->Paginator->sort('answer') ?></th>
                    <th><?= $this->Paginator->sort('student_id') ?></th>
                    <th><?= $this->Paginator->sort('question_id') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($answerSheets as $answerSheet): ?>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <td><?= $answerSheet->has('question') ? $this->Html->link($courseTable->find('all')->where(['id'=>$lessonTable->find('all')->where(['id'=>$answerSheet->question->lesson_id])->first()->course_id])->first()->name, ['controller' => 'Courses', 'action' => 'view', $lessonTable->find('all')->where(['id'=>$answerSheet->question->lesson_id])->first()->course_id]) : '' ?></td>
                        <td><?= $answerSheet->has('question') ? $lessonTable->find('all')->where(['id'=>$answerSheet->question->lesson_id])->first()->topic :"" ?></td>
                        <td><?= $answerSheet->has('question') ? h($answerSheet->question->question) : '' ?></td>
                        <td><?= h($answerSheet->answer) ?></td>
                    <?php else: ?>
                        <td><?= h($answerSheet->answer) ?></td>
                        <td><?= $answerSheet->has('student') ? $this->Html->link($answerSheet->student->id, ['controller' => 'Students', 'action' => 'view', $answerSheet->student->id]) : '' ?></td>
                        <td><?= $answerSheet->has('question') ? $this->Html->link($answerSheet->question->id, ['controller' => 'Questions', 'action' => 'view', $answerSheet->question->id]) : '' ?></td>
                        <td class="actions">
                            <?= $this->Html->link(__('View'), ['action' => 'view', $answerSheet->id]) ?>
                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $answerSheet->id]) ?>
                            <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $answerSheet->id], ['confirm' => __('Are you sure you want to delete # {0}?', $answerSheet->id)]) ?>
                        </td>
                    <?php endif; ?>

                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<script src="js/datatables-simple-demo.js"></script>
