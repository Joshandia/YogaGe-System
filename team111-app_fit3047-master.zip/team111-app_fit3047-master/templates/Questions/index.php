<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Question[]|\Cake\Collection\CollectionInterface $questions
 * @var \App\Model\Entity\Question $checkStudent
 * @var \App\Model\Entity\Question $topic
 */
?>
<div class="questions index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?=$checkStudent == 1 ? __('Questions of Lesson '.$topic) : __('Questions') ?></h1>
        <?= $checkStudent == 1 ? '' : $this->Html->link(__('Set Award'), ['controller' => 'Awards', 'action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>

    <div class="table-responsive">
        <table class="dataTable-table">
            <thead>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <th><?= $this->Paginator->sort('Question Description') ?></th>
                        <th class="actions"><?= __('Actions') ?></th>
                    <?php else: ?>
                        <th><?= $this->Paginator->sort('lesson') ?></th>
                        <th><?= $this->Paginator->sort('question') ?></th>
                        <th><?= $this->Paginator->sort('answer') ?></th>
                        <th class="actions"><?= __('Actions') ?></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($questions as $question): ?>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <td><?= h($question->question) ?></td>
                        <td class="actions">
                            <?= $this->Html->link(__('Answer'), ['controller' => 'AnswerSheets' ,'action' => 'answer', $question->id, $question->question]) ?>
                        </td>
                    <?php else: ?>
                        <td><?= $question->has('lesson') ? $this->Html->link($question->lesson->topic, ['controller' => 'Lessons', 'action' => 'view', $question->lesson->id]) : '' ?></td>
                        <td><?= h($question->question) ?></td>
                        <td><?= h($question->answer) ?></td>
                        <td class="actions">
                            <?= $this->Html->link(__('View'), ['action' => 'view', $question->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $question->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $question->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete question: {0}?', $question->question)]) ?>
                        </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="js/datatables-simple-demo.js"></script>
