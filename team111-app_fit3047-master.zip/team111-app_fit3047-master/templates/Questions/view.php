<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Question $question
 * @var \App\Model\Entity\Question $studentTable
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="questions view content">
            <h3><?= h('Question: ' . $question->question) ?></h3>
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Lesson') ?></th>
                    <td><?= $question->has('lesson') ? $this->Html->link($question->lesson->topic, ['controller' => 'Lessons', 'action' => 'view', $question->lesson->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Question') ?></th>
                    <td><?= h($question->question) ?></td>
                </tr>
                <tr>
                    <th><?= __('Reference Answer') ?></th>
                    <td><?= h($question->answer) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Student Answer Sheets') ?></h4>
                <?php if (!empty($question->answer_sheets)) : ?>
                    <div class="table-responsive">
                        <table class="dataTable-table">
                        <tr>
                            <th><?= __('Student Name') ?></th>
                            <th><?= __('Answer') ?></th>
                            <th><?= __('Score') ?></th>
                            <th class="actions"><?= __('Mark As') ?></th>
                        </tr>
                        <?php foreach ($question->answer_sheets as $answerSheets) : ?>
                        <tr>
                            <td><?= $this->Html->link($studentTable->find('all')->where(['id'=>$answerSheets->student_id])->first()->firstname . ' ' . $studentTable->find('all')->where(['id'=>$answerSheets->student_id])->first()->lastname, ['controller' => 'Students', 'action' => 'view', $answerSheets->student_id]) ?></td>
                            <td><?= h($answerSheets->answer) ?></td>
                            <td><?= h($answerSheets->status) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Pass'), ['controller' => 'AnswerSheets', 'action' => 'pass', $answerSheets->id], ['class' => 'btn btn-dark']) ?>
                                <?= $this->Html->link(__('Fail'), ['controller' => 'AnswerSheets', 'action' => 'fail', $answerSheets->id], ['class' => 'btn btn-dark']) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="mt-4">
                <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            </div>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
