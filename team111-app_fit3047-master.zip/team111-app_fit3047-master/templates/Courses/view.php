<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Course $course
 * @var \App\Model\Entity\Course $checkStudent
 * @var \App\Model\Entity\Course $studentTable
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="courses view content">
            <h1 class="heading"><?= __('Course: ') ?><?= $course->name ?></h1>
            <aside class="column">
                <div class="side-nav">
                    <?php if ($checkStudent == 0): ?>
                        <?= $this->Html->link(__('Edit Course'), ['action' => 'edit', $course->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Form->postLink(__('Delete Course'), ['action' => 'delete', $course->id], ['confirm' => __('Are you sure you want to delete course: {0}?', $course->name), 'class' => 'btn btn-dark']) ?>
                    <?php endif ?>
                </div>
            </aside>
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($course->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Description') ?></th>
                    <td><?= h($course->description) ?></td>
                </tr>
                <tr>
                    <th><?= __('Type') ?></th>
                    <td><?= h($course->type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Level') ?></th>
                    <td><?= h($course->level) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Certification') ?></h4>

                <?php if (!empty($course->certifications)) : ?>
                    <div class="table-responsive">
                        <table class="dataTable-table">
                            <tr>
                                <th><?= __('Title') ?></th>
                                <?php if ($checkStudent == 0): ?>
                                    <th class="actions"><?= __('Actions') ?></th>
                                <?php endif; ?>
                            </tr>
                            <?php foreach ($course->certifications as $certifications) : ?>
                            <tr>
                                <td><?= $this->Html->link($certifications->title, ['controller' => 'Certifications', 'action' => 'view', $certifications->id]) ?></td>
                                <?php if ($checkStudent == 0): ?>
                                    <td class="actions">
                                        <?= $this->Html->link(__('View'), ['controller' => 'Certifications', 'action' => 'view', $certifications->id], ['class' => 'btn btn-dark']) ?>
                                        <?= $this->Html->link(__('Edit'), ['controller' => 'Certifications', 'action' => 'edit', $certifications->id], ['class' => 'btn btn-dark']) ?>
                                        <?= $this->Form->postLink(__('Delete'), ['controller' => 'Certifications', 'action' => 'delete', $certifications->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete certification {0}?', $certifications->title)]) ?>
                                    </td>
                                <?php endif; ?>

                            </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                <?php else:?>
                    <?php if ($checkStudent == 0): ?>
                        <?= $this->Html->link(__('Upload Certification'), ['controller' => 'Certifications', 'action' => 'add', $course->id], ['class' => 'btn btn-dark']) ?>
                    <?php else: ?>
                        <h6>No related certificate for now</h6>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
            <div class="related">
                <?php if ($checkStudent == 0): ?>
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                        <h4><?= __('Related Enrolments') ?></h4>
                        <?= $checkStudent == 1 ? '' : $this->Html->link(__('Add Enrolment'), ['controller' => 'enrolments', 'action' => 'add', $course->id], ['class' => 'btn btn-dark']) ?>
                    </div>

                    <?php if (!empty($course->enrolments)) : ?>
                        <div class="table-responsive">
                            <table class="dataTable-table">
                                <tr>
                                    <th><?= __('Student') ?></th>
                                    <th><?= __('Start Date') ?></th>
                                    <th><?= __('Paid Fee') ?></th>
                                    <th class="actions"><?= __('Actions') ?></th>
                                </tr>
                                <?php foreach ($course->enrolments as $enrolment) : ?>
                                <tr>
                                    <td><?= $this->Html->link($studentTable->find('all')->where(['id'=>$enrolment->student_id])->first()->firstname . ' ' . $studentTable->find('all')->where(['id'=>$enrolment->student_id])->first()->lastname, ['controller' => 'Students', 'action' => 'view', $enrolment->student_id]) ?></td>
                                    <td><?= h($enrolment->startdate) ?></td>
                                    <td><?= h($enrolment->payfee) ?></td>
                                    <td class="actions">
                                        <?= $this->Html->link(__('Edit'), ['controller' => 'Enrolments', 'action' => 'edit', $enrolment->id], ['class' => 'btn btn-dark']) ?>
                                        <?= $this->Form->postLink(__('Delete'), ['controller' => 'Enrolments', 'action' => 'delete', $enrolment->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete the enrolment of {0}?', $studentTable->find('all')->where(['id'=>$enrolment->student_id])->first()->firstname . ' ' . $studentTable->find('all')->where(['id'=>$enrolment->student_id])->first()->lastname)]) ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    <?php else: ?>
                        <h6>No related enrolments for now</h6>
                    <?php endif; ?>
                <?php endif;?>
            </div>
            <div class="related">
                <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                    <h4><?= __('Related Lessons') ?></h4>
                    <?= $checkStudent == 1 ? '' : $this->Html->link(__('Add Lesson'), ['controller' => 'lessons', 'action' => 'add', $course->id], ['class' => 'btn btn-dark']) ?>
                </div>
                <?php if (!empty($course->lessons)) : ?>
                <?php if ($checkStudent == 1): ?>
                    <h6 style="color: #dc3545"><?= __('Please remember to answer the related questions after watching the video.') ?></h6>
                <?php endif;?>
                <div class="table-responsive">
                    <table class="dataTable-table">
                        <tr>
                            <th><?= __('Topic') ?></th>
                            <th><?= __('Lesson Link') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($course->lessons as $lesson) : ?>
                        <tr>
                            <td><?= $this->Html->link($lesson->topic, ['controller' => 'Lessons', 'action' => 'view', $lesson->id]) ?></td>


                            <td><?= h($lesson->record_link) ?></td>
                            <?php if ($checkStudent == 1): ?>
                                <td class="actions">
                                    <?= $this->Html->link(__('Answer Question'), ['controller' => 'Questions', 'action' => "index", $lesson->id], ['class' => 'btn btn-dark']) ?>
                                </td>
                            <?php else: ?>
                                <td class="actions">
                                    <?= $this->Html->link(__('View'), ['controller' => 'Lessons', 'action' => 'view', $lesson->id], ['class' => 'btn btn-dark']) ?>
                                    <?= $this->Html->link(__('Edit'), ['controller' => 'Lessons', 'action' => 'edit', $lesson->id], ['class' => 'btn btn-dark']) ?>
                                    <?= $this->Form->postLink(__('Delete'), ['controller' => 'Lessons', 'action' => 'delete', $lesson->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete lesson: {0}?', $lesson->topic)]) ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php else:?>
                    <h6>No related lessons for now</h6>
                <?php endif; ?>

            <div class="mt-4">
                <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            </div>
        </div>
    </div>
</div>

