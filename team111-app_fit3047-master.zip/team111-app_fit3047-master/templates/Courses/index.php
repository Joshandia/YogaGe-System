<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Course[]|\Cake\Collection\CollectionInterface $courses
 * @var \App\Model\Entity\Course $checkStudent
 */
?>
<div class="courses index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?= __('Courses') ?></h1>
        <?= $checkStudent == 1 ? '' : $this->Html->link(__('New Course'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>

    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('description') ?></th>
                    <th><?= $this->Paginator->sort('type') ?></th>
                    <th><?= $this->Paginator->sort('level') ?></th>
                    <?php if ($checkStudent == 0): ?>
                        <th class="actions"><?= __('Actions') ?></th>
                    <?php endif;?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                <tr>
                    <td><?= h($course->name) ?></td>
                    <td><?= h($course->description) ?></td>
                    <td><?= h($course->type) ?></td>
                    <td><?= h($course->level) ?></td>

                    <?php if ($checkStudent == 0): ?>
                        <td class="actions">
                            <?= $this->Html->link(__('View'), ['action' => 'view', $course->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $course->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $course->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete course: {0}?', $course->name)]) ?>
                        </td>
                    <?php endif;?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
