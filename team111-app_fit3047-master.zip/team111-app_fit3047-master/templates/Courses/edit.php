<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Course $course
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="courses form content">
            <?= $this->Form->create($course) ?>
            <fieldset>
                <legend><?= __('Edit Course') ?></legend>
                <?php
                    echo $this->Form->control('name');
                    echo $this->Form->control('description');
                    echo $this->Form->control('type', ['options' =>['Online'=>'Online', 'Hybrid'=>'Hybrid']]);
                    echo $this->Form->control('level', ['options' =>['Beginner'=>'Beginner','Intermediate'=>'Intermediate', 'Advanced'=>'Advanced']]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
