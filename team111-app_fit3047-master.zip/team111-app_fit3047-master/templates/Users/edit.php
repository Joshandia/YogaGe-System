<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="users form content">
            <?= $this->Form->create($user) ?>
            <fieldset>
                <legend><?= __('Edit User') ?></legend>
                <?php
                    echo $this->Form->control('name');
                    echo $this->Form->control('email');
                    echo $this->Form->control('password');
                    echo $this->Form->control('type', ['options' =>['Student'=>'Student', 'Admin'=>'Admin']]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
