<div class="users form">
    <?= $this->Flash->render() ?>
    <h3>Reset Password</h3>
    <?= $this->Form->create() ?>
    <fieldset>
        <legend><?= __('Please enter your new password') ?></legend>
        <?= $this->Form->input('password', ['required' => true] ,['class' => 'form-control']) ?>
    </fieldset>
    <?= $this->Form->button('Reset password',['class'=>'btn btn-primary']); ?>
    <?= $this->Form->end() ?>
</div>
