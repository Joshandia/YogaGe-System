<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User[]|\Cake\Collection\CollectionInterface $users
 */
?>

<div class="users index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?= __('Admin') ?></h1>
        <?= $this->Html->link(__('Add Admin'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>
    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('email') ?>
                    </th>
                    <th><?= $this->Paginator->sort('type') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= h($user->name) ?></td>
                    <td><?= $this->Html->link(h($user->email), 'mailto'.$user->email ) ?></td>
                    <td><?= h($user->type) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $user->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $user->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $user->id],  ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete user: {0}?', $user->name)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>
<script src="js/datatables-simple-demo.js"></script>
