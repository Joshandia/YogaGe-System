<?php echo $this->Flash->render() ?>
<?= $this->Form->create() ?>
<?= $this->Form->control('email'); ?>
<?= $this->Form->submit() ?>
<br>
<a href="<?= $this->Url->build('/') ?>">Back</a>
<?= $this->Form->end() ?>
