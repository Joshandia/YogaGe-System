<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Lesson $lesson
 * @var \App\Model\Entity\Lesson $courseName
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="lessons form content">
            <?= $this->Form->create($lesson) ?>
            <fieldset>
                <legend><?= __('Add Lesson for Course ' . $courseName) ?></legend>
                <?php
                    echo $this->Form->control('topic');
                    echo $this->Form->control('record_link');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>




