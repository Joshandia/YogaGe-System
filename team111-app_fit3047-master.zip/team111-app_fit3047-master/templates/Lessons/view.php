<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Lesson $lesson
 * @var \App\Model\Entity\Lesson $checkStudent
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="lessons view content">
            <h3><?= h('Lesson: '.$lesson->topic) ?></h3>
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Course') ?></th>
                    <td><?= $lesson->has('course') ? $this->Html->link($lesson->course->name, ['controller' => 'Courses', 'action' => 'view', $lesson->course->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Lesson Topic') ?></th>
                    <td><?= h($lesson->topic) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lesson Record Link') ?></th>
                    <td><?= h($lesson->record_link) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Questions') ?></h4>
                <?= $this->Html->link(__('Create Question'), ['controller' => 'Questions', 'action' => 'add', $lesson->id], ['class' => 'btn btn-dark']) ?>

                <?php if (!empty($lesson->questions)) : ?>
                <div class="table-responsive">
                    <table class="dataTable-table">
                        <tr>
                            <?php if ($checkStudent == 1): ?>
                                <th><?= __('Question') ?></th>
                            <?php else: ?>
                                <th><?= __('Question') ?></th>
                                <th><?= __('Reference Answer') ?></th>
                                <th class="actions"><?= __('Actions') ?></th>
                            <?php endif;?>
                        </tr>
                        <?php foreach ($lesson->questions as $questions) : ?>
                        <tr>
                            <?php if ($checkStudent == 1): ?>
                                <td><?= h($questions->question) ?></td>
                            <?php else: ?>
                                <td><?= h($questions->question) ?></td>
                                <td><?= h($questions->answer) ?></td>
                                <td class="actions">
                                    <?= $this->Html->link(__('View Answer Sheet'), ['controller' => 'Questions', 'action' => 'view', $questions->id], ['class' => 'btn btn-dark']) ?>
                                    <?= $this->Html->link(__('Edit'), ['controller' => 'Questions', 'action' => 'edit', $questions->id], ['class' => 'btn btn-dark']) ?>
                                    <?= $this->Form->postLink(__('Delete'), ['controller' => 'Questions', 'action' => 'delete', $questions->id], ['class' => 'btn btn-dark', 'confirm' => __('Are you sure you want to delete question: {0}?', $questions->question)]) ?>
                                </td>
                            <?php endif;?>

                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php else:?>
                    <h6>No related questions for now</h6>
                <?php endif; ?>

                <div class="mt-4">
                    <?= $this->Html->link(__('Back'), ['controller' => 'courses', 'action' => 'view', $lesson->course_id], ['class' => 'btn btn-secondary']) ?>
                </div>

            </div>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
