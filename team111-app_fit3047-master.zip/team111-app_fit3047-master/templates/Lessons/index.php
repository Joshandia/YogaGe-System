<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Lesson[]|\Cake\Collection\CollectionInterface $lessons
 */
?>
<div class="lessons index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?= __('Lessons') ?></h1>
        <?= $this->Html->link(__('New Lesson'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>
    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('Course') ?></th>
                    <th><?= $this->Paginator->sort('Lesson Topic') ?></th>
                    <th><?= $this->Paginator->sort('Lesson Video Link') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lessons as $lesson): ?>
                <tr>
                    <td><?= $lesson->has('course') ? $this->Html->link($lesson->course->name, ['controller' => 'Courses', 'action' => 'view', $lesson->course->id]) : '' ?></td>
                    <td><?= h($lesson->topic) ?></td>
                    <td><?= h($lesson->record_link) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $lesson->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $lesson->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $lesson->id], ['class' => 'btn btn-dark', 'confirm' => __('Are you sure you want to delete # {0}?', $lesson->topic)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
