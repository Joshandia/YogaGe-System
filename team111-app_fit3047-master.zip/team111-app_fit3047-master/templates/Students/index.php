<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Student[]|\Cake\Collection\CollectionInterface $students
 */
?>
<div class="students index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?= __('Students') ?></h1>
        <?= $this->Html->link(__('New Student'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>
    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('firstname') ?></th>
                    <th><?= $this->Paginator->sort('lastname') ?></th>
                    <th><?= $this->Paginator->sort('dob') ?></th>
                    <th><?= $this->Paginator->sort('gender') ?></th>
                    <th><?= $this->Paginator->sort('phone') ?></th>
                    <th><?= $this->Paginator->sort('email') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                <tr>
                    <td><?= h($student->firstname) ?></td>
                    <td><?= h($student->lastname) ?></td>
                    <td><?= h($student->dob) ?></td>
                    <td><?= h($student->gender) ?></td>
                    <td><?= h($student->phone) ?></td>
                    <td><?= $this->Html->link(h($student->email), 'mailto'.$student->email ) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $student->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $student->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $student->id], ['class' => 'btn btn-dark', 'confirm' => __('Are you sure you want to delete Student {0}: {1}?', $student->id, $student->firstname. ' '. $student->lastname)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
