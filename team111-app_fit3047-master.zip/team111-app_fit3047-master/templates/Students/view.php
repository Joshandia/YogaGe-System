<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Student $student
 * @var \App\Model\Entity\Student $certificationTable
 * @var \App\Model\Entity\Student $courseTable
 * @var \App\Model\Entity\Student $questionTable
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h1 class="heading"><?= __('Student ID: ') ?><?= $this->Number->format($student->id) ?></h1>
            <?= $this->Html->link(__('Edit Student'), ['action' => 'edit', $student->id], ['class' => 'btn btn-dark']) ?>
            <?= $this->Form->postLink(__('Delete Student'), ['action' => 'delete', $student->id], ['confirm' => __('Are you sure you want to delete # {0}?', $student->id), 'class' => 'btn btn-dark']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="table-responsive">
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Firstname') ?></th>
                    <td><?= h($student->firstname) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname') ?></th>
                    <td><?= h($student->lastname) ?></td>
                </tr>
                <tr>
                    <th><?= __('Gender') ?></th>
                    <td><?= h($student->gender) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone') ?></th>
                    <td><?= h($student->phone) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= $this->Html->link(h($student->email), 'mailto'.$student->email ) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dob') ?></th>
                    <td><?= h($student->dob) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Answer Sheets') ?></h4>
                <?php if (!empty($student->answer_sheets)) : ?>
                    <div class="table-responsive">
                        <table class="dataTable-table">
                        <tr>
                            <th><?= __('Question') ?></th>
                            <th><?= __('Answer') ?></th>
                            <th><?= __('Status') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($student->answer_sheets as $answerSheets) : ?>
                        <tr>
                            <td><?= $this->Html->link($questionTable->find('all')->where(['id'=>$answerSheets->question_id])->first()->question, ['controller' => 'Questions', 'action' => 'view', $questionTable->find('all')->where(['id'=>$answerSheets->question_id])->first()->id]) ?></td>

                            <td><?= h($answerSheets->answer) ?></td>
                            <td><?= h($answerSheets->status) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Pass'), ['controller' => 'AnswerSheets', 'action' => 'pass', $answerSheets->id], ['class' => 'btn btn-dark']) ?>
                                <?= $this->Html->link(__('Fail'), ['controller' => 'AnswerSheets', 'action' => 'fail', $answerSheets->id], ['class' => 'btn btn-dark']) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php else:?>
                    <h6>The student have not answer any question at the moment</h6>
                <?php endif; ?>
            </div>
            <div class="related">
                <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                    <h4><?= __('Related Awards') ?></h4>
                    <?= $this->Html->link(__('Set Award'), ['controller' => 'awards', 'action' => 'add', $student->id], ['class' => 'btn btn-dark']) ?>
                </div>

                <?php if (!empty($student->awards)) : ?>
                    <div class="table-responsive">
                        <table class="dataTable-table">
                        <tr>
                            <th><?= __('Certification Title') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($student->awards as $awards) : ?>
                        <tr>
                            <td><?= $this->Html->link($certificationTable->find('all')->where(['id'=>$awards->certification_id])->first()->title, ['controller' => 'Certifications', 'action' => 'view', $certificationTable->find('all')->where(['id'=>$awards->certification_id])->first()->id]) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Awards', 'action' => 'edit', $awards->id], ['class' => 'btn btn-dark']) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Awards', 'action' => 'delete', $awards->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete awards of {0}?', $certificationTable->find('all')->where(['id'=>$awards->certification_id])->first()->title)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php else:?>
                    <h6>The student do not have any certification at the moment</h6>
                <?php endif; ?>

            </div>
            <div class="related">
                <h4><?= __('Related Enrolments') ?></h4>
                <?php if (!empty($student->enrolments)) : ?>
                    <div class="table-responsive">
                        <table class="dataTable-table">
                        <tr>
                            <th><?= __('Course') ?></th>
                            <th><?= __('Type') ?></th>
                            <th><?= __('Startdate') ?></th>
                            <th><?= __('Payfee') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($student->enrolments as $enrolments) : ?>
                        <tr>
                            <td><?= $this->Html->link($courseTable->find('all')->where(['id'=>$enrolments->course_id])->first()->name, ['controller' => 'Courses', 'action' => 'view', $courseTable->find('all')->where(['id'=>$enrolments->course_id])->first()->id]) ?></td>
                            <td><?= h($enrolments->type) ?></td>
                            <td><?= h($enrolments->startdate) ?></td>
                            <td><?= h($enrolments->payfee) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Enrolments', 'action' => 'edit', $enrolments->id], ['class' => 'btn btn-dark']) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Enrolments', 'action' => 'delete', $enrolments->id], ['class' => 'btn btn-dark', 'confirm' => __('Are you sure you want to remove this student from the course {0}?', $courseTable->find('all')->where(['id'=>$enrolments->course_id])->first()->name)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php else:?>
                    <h6>The student is not enrolled in any course at the moment</h6>
                <?php endif; ?>
            </div>
            <div class="mt-4">
                <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            </div>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
