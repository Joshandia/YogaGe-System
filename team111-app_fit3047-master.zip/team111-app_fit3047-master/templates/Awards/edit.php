<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Award $award
 * @var string[]|\Cake\Collection\CollectionInterface $students
 * @var string[]|\Cake\Collection\CollectionInterface $certifications
 */
?>
<div class="row">
        <!--<div class="side-nav">
            <?= $this->Form->postLink(
                __('Delete Award'),
                ['action' => 'delete', $award->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $award->id), 'class' => 'btn btn-dark']
            ) ?>
            </div>-->
    <div class="column-responsive column-80">
        <div class="awards form content">
            <?= $this->Form->create($award) ?>
            <fieldset>
                <h1><?= __('Edit Award') ?></h1>
                <?php
                    echo $this->Form->control('student_id', ['options' => $students]);
                    echo $this->Form->control('certification_id', ['options' => $certifications]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Cancel" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
