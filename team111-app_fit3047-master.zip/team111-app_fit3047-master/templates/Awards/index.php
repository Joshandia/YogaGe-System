<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Award[]|\Cake\Collection\CollectionInterface $awards
 * @var \App\Model\Entity\Award[]|\Cake\Collection\CollectionInterface $checkStudent
 */
?>
<div class="awards index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?=$checkStudent == 1 ? __('My Certification') : __('Awards') ?></h1>
        <?= $checkStudent == 1 ? '' : $this->Html->link(__('Set Award'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>

    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <th><?= $this->Paginator->sort('Certification Title') ?></th>
                        <th><?= $this->Paginator->sort('Related Course ID') ?></th>
                    <?php else: ?>
                        <th><?= $this->Paginator->sort('Student') ?></th>
                        <th><?= $this->Paginator->sort('Certification') ?></th>
                        <th class="actions"><?= __('Actions') ?></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($awards as $award): ?>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <td><?= $award->has('certification') ? h($award->certification->title): '' ?></td>
                        <td><?= $award->has('certification') ? $this->Html->link($award->certification->title, ['controller' => 'Courses', 'action' => 'view', $award->certification->course_id]) : '' ?></td>
                    <?php else: ?>
                        <td><?= $award->has('student') ? $this->Html->link($award->student->firstname . ' ' . $award->student->lastname, ['controller' => 'Students', 'action' => 'view', $award->student->id]) : '' ?></td>
                        <td><?= $award->has('certification') ? $this->Html->link($award->certification->title, ['controller' => 'Certifications', 'action' => 'view', $award->certification->id]) : '' ?></td>
                        <td class="actions">
                            <?= $this->Html->link(__('View'), ['action' => 'view', $award->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $award->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $award->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete Award (Student{0}, {1})?', $award->student_id, $award->certification->title)]) ?>
                        </td>
                    <?php endif; ?>


                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="js/datatables-simple-demo.js"></script>
