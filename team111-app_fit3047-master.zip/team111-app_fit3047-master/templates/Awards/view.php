<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Award $award
 */
?>
<div class="row">

    <div class="column-responsive column-80">
        <div class="card-body">
            <table class="dataTable-table">
            <tr>
                    <th><?= __('Student') ?></th>
                    <td><?= $award->has('student') ? $this->Html->link($award->student->firstname . ' ' . $award->student->lastname, ['controller' => 'Students', 'action' => 'view', $award->student->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Certification') ?></th>
                    <td><?= $award->has('certification') ? $this->Html->link($award->certification->title, ['controller' => 'Certifications', 'action' => 'view', $award->certification->id]) : '' ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
<script src="js/datatables-simple-demo.js"></script>
