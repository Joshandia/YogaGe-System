<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Award $award
 * @var \App\Model\Entity\Award $studentName
 * @var \Cake\Collection\CollectionInterface|string[] $certifications
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="awards form content">
            <?= $this->Form->create($award) ?>
            <fieldset>
                <legend><?= __('Set Award for Student: ' . $studentName) ?></legend>
                <?php
                echo $this->Form->control('certification_id', ['options' => $certifications]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>

<script src="js/datatables-simple-demo.js"></script>
