<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Certification $certification
 * @var \App\Model\Entity\Certification $courseName
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="certifications form content">
            <?= $this->Form->create($certification) ?>
            <fieldset>
                <legend><?= __('Add Certification for Course ' . $courseName) ?></legend>
                <?php
                    echo $this->Form->control('title');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>

<script src="js/datatables-simple-demo.js"></script>
