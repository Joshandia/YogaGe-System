<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Certification $certification
 * @var \App\Model\Entity\Certification $studentTable
 */
?>
<div class="row">
    <div class="column-responsive column-80">
        <div class="certifications view content">
            <h3><?= h('Certification: '.$certification->title) ?></h3>
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Course') ?></th>
                    <td><?= $certification->has('course') ? $this->Html->link($certification->course->name, ['controller' => 'Courses', 'action' => 'view', $certification->course->id]) : '' ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Awards') ?></h4>
                <?php if (!empty($certification->awards)) : ?>
                    <div class="table-responsive">
                        <table class="dataTable-table">
                            <tr>
                                <th><?= __('Student') ?></th>
                                <th class="actions"><?= __('Actions') ?></th>
                            </tr>
                            <?php foreach ($certification->awards as $awards) : ?>
                                <tr>
                                    <td><?= h($studentTable->find('all')->where(['id'=>$awards->student_id])->first()->firstname . ' '. $studentTable->find('all')->where(['id'=>$awards->student_id])->first()->lastname) ?></td>
                                    <td class="actions">
                                        <?= $this->Html->link(__('View'), ['controller' => 'Awards', 'action' => 'view', $awards->id], ['class' => 'btn btn-dark']) ?>
                                        <?= $this->Html->link(__('Edit'), ['controller' => 'Awards', 'action' => 'edit', $awards->id], ['class' => 'btn btn-dark']) ?>
                                        <?= $this->Form->postLink(__('Delete'), ['controller' => 'Awards', 'action' => 'delete', $awards->id], ['class' => 'btn btn-dark', 'confirm' => __('Are you sure you want to delete the award for {0}?', $studentTable->find('all')->where(['id'=>$awards->student_id])->first()->firstname)]) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                <?php else: ?>
                    <h6>No related certificate for now</h6>
                <?php endif; ?>

                <div class="mt-4">
                    <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
                </div>

            </div>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
