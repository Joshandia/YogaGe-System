<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Certification[]|\Cake\Collection\CollectionInterface $certifications
 */
?>
<div class="certifications index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?= __('Certifications') ?></h1>
        <?= $this->Html->link(__('New Certification'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>

    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('course') ?></th>
                    <th><?= $this->Paginator->sort('Certification Title') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($certifications as $certification): ?>
                <tr>
                    <td><?= $certification->has('course') ? $this->Html->link($certification->course->name, ['controller' => 'Courses', 'action' => 'view', $certification->course->id]) : '' ?></td>
                    <td><?= h($certification->title) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $certification->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $certification->id], ['class' => 'btn btn-dark']) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $certification->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete certification: {0}?', $certification->title)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<script src="js/datatables-simple-demo.js"></script>
