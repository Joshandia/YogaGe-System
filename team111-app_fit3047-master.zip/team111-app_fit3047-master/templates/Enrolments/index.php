<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Enrolment[]|\Cake\Collection\CollectionInterface $enrolments
 * @var \App\Model\Entity\Enrolment[]|\Cake\Collection\CollectionInterface $checkStudent
 */
?>
<div class="enrolments index content">
    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
        <h1><?=$checkStudent == 1 ? __('My Course') : __('Enrolments') ?></h1>
        <?= $checkStudent == 1 ? '' : $this->Html->link(__('Add Enrolment'), ['action' => 'add'], ['class' => 'btn btn-dark']) ?>
    </div>
    <div class="table-responsive">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <th><?= $this->Paginator->sort('name') ?></th>
                        <th><?= $this->Paginator->sort('description') ?></th>
                        <th><?= $this->Paginator->sort('type') ?></th>
                        <th><?= $this->Paginator->sort('level') ?></th>
                    <?php else: ?>
                        <th><?= $this->Paginator->sort('Student') ?></th>
                        <th><?= $this->Paginator->sort('Course') ?></th>
                        <th><?= $this->Paginator->sort('Type') ?></th>
                        <th><?= $this->Paginator->sort('Start Date') ?></th>
                        <th><?= $this->Paginator->sort('Paid Fee') ?></th>
                    <?php endif;?>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($enrolments as $enrolment): ?>
                <tr>
                    <?php if ($checkStudent == 1): ?>
                        <td><?= h($enrolment->course->name) ?></td>
                        <td><?= h($enrolment->course->description) ?></td>
                        <td><?= h($enrolment->course->type) ?></td>
                        <td><?= h($enrolment->course->level) ?></td>
                        <td class="actions">
                            <a class="btn btn-dark" href="<?= $this->Url->build('/courses/view/' . $enrolment->course_id) ?>"> View</a>
                        </td>
                    <?php else: ?>
                        <td><?= ($enrolment->has('student') ? $this->Html->link($enrolment->student->firstname . ' ' . $enrolment->student->lastname, ['controller' => 'Students', 'action' => 'view', $enrolment->student->id]) : '') ?></td>
                        <td><?= ($enrolment->has('course') ? $this->Html->link($enrolment->course->name, ['controller' => 'Courses', 'action' => 'view', $enrolment->course->id]) : '') ?></td>
                        <td><?= h($enrolment->type) ?></td>
                        <td><?= h($enrolment->startdate) ?></td>
                        <td><?= ($enrolment->payfee === null ? '' : $this->Number->format($enrolment->payfee)) ?></td>
                        <td class="actions">
                            <?= $this->Html->link(__('View'), ['action' => 'view', $enrolment->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $enrolment->id], ['class' => 'btn btn-dark']) ?>
                            <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $enrolment->id], ['class' => 'btn btn-dark','confirm' => __('Are you sure you want to delete enrolment: {0}: {1}?', $enrolment->student->firstname.' '.$enrolment->student->lastname, $enrolment->course->name)]) ?>
                        </td>
                    <?php endif;?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<script src="js/datatables-simple-demo.js"></script>
