<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Enrolment $enrolment
 * @var \Cake\Collection\CollectionInterface|string[] $students
 * @var \App\Model\Entity\Enrolment $courseName
 */
?>

<div class="row">
    <div class="column-responsive column-80">
        <div class="enrolments form content">
            <?= $this->Form->create($enrolment) ?>
            <fieldset>
                <legend><?= __('Add Enrolment for Course '. $courseName) ?></legend>
                <?php
                echo $this->Form->control('student_id', ['options' => $students]);
                echo $this->Form->control('startdate', ['empty' => true]);
                echo $this->Form->control('payfee');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
