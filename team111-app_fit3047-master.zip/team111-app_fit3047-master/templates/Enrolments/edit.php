<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Enrolment $enrolment
 * @var \App\Model\Entity\Enrolment $studentName
 * @var \App\Model\Entity\Enrolment $courseName
 */
?>

<div class="row">
    <div class="column-responsive column-80">
        <div class="enrolments form content">
            <?= $this->Form->create($enrolment) ?>
            <fieldset>
                <legend><?= __('Edit ' . $courseName .' Enrolment of Student: ' . $studentName ) ?></legend>
                <?php
                echo $this->Form->control('startdate', ['empty' => true]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit'), ['class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
<script src="js/datatables-simple-demo.js"></script>
