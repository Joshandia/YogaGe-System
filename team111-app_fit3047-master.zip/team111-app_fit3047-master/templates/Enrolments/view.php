<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Enrolment $enrolment
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h1 class="heading">Enrolment:  <?= __($enrolment->course->name ) ?></h1>
            <?= $this->Html->link(__('Edit Enrolment'), ['action' => 'edit', $enrolment->id], ['class' => 'btn btn-dark']) ?>
            <?= $this->Form->postLink(__('Delete Enrolment'), ['action' => 'delete', $enrolment->id], ['confirm' => __('Are you sure you want to delete # {0}?', $enrolment->id), 'class' => 'btn btn-dark']) ?>
            <input type="button" class="btn btn-secondary" value="Back" onclick="history.back();"/>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="card-body">
            <table class="dataTable-table">
                <tr>
                    <th><?= __('Student') ?></th>
                    <td><?= $enrolment->has('student') ? $this->Html->link($enrolment->student->firstname . ' ' . $enrolment->student->lastname, ['controller' => 'Students', 'action' => 'view', $enrolment->student->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Course') ?></th>
                    <td><?= $enrolment->has('course') ? $this->Html->link($enrolment->course->name, ['controller' => 'Courses', 'action' => 'view', $enrolment->course->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Type') ?></th>
                    <td><?= h($enrolment->type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Start Date') ?></th>
                    <td><?= h($enrolment->startdate) ?></td>
                </tr>
                <tr>
                    <th><?= __('Pay Fee') ?></th>
                    <td><?= $enrolment->payfee === null ? '' : $this->Number->format($enrolment->payfee) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<script src="js/datatables-simple-demo.js"></script>
