<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;

/**
 * Awards Controller
 *
 * @property \App\Model\Table\AwardsTable $Awards
 * @method \App\Model\Entity\Award[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AwardsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewActive();
        $this->paginate = [
            'contain' => ['Students', 'Certifications'],
        ];

        $checkStudent = 0;

        if ($this->userIdentification() == "Student"){
            $awards = $this->paginate($this->Awards->find('all', array('conditions'=>array('Students.id'=>$this->getStudentID()))));
            $checkStudent = 1;
        }else{
            $awards = $this->paginate($this->Awards);
        }


        $this->set(compact('awards', 'checkStudent'));
    }

    /**
     * View method
     *
     * @param string|null $id Award id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $award = $this->Awards->get($id, [
            'contain' => ['Students', 'Certifications'],
        ]);

        $this->set(compact('award'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($studentID = null)
    {
        $this->viewActive();
        $award = $this->Awards->newEmptyEntity();
        if ($this->request->is('post')) {
            $award = $this->Awards->patchEntity($award, $this->request->getData());
            $award->student_id = $studentID;
            if ($this->Awards->save($award)) {
                $this->Flash->success(__('The award has been saved.'));

                return $this->redirect(['controller' => 'students', 'action' => 'view', $award->student_id]);
            }
            $this->Flash->error(__('The award could not be saved. Please, try again.'));
        }
        $studentTable = TableRegistry::get('Students');
        $studentName = $studentTable->find('all')->where(['id'=>$studentID])->first()->firstname;

        $certifications = $this->Awards->Certifications->find('list', ['limit' => 200])->all();
        $this->set(compact('award', 'studentName', 'certifications'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Award id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $award = $this->Awards->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $award = $this->Awards->patchEntity($award, $this->request->getData());
            if ($this->Awards->save($award)) {
                $this->Flash->success(__('The award has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The award could not be saved. Please, try again.'));
        }
        $students = $this->Awards->Students->find('list', ['limit' => 200])->all();
        $certifications = $this->Awards->Certifications->find('list', ['limit' => 200])->all();
        $this->set(compact('award', 'students', 'certifications'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Award id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {   $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $award = $this->Awards->get($id);
        if ($this->Awards->delete($award)) {
            $this->Flash->success(__('The award has been deleted.'));
        } else {
            $this->Flash->error(__('The award could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
