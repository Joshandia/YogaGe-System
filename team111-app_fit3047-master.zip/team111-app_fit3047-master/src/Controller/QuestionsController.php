<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;
/**
 * Questions Controller
 *
 * @property \App\Model\Table\QuestionsTable $Questions
 * @method \App\Model\Entity\Question[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class QuestionsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index($id = null)
    {
        $this->viewActive();
        $this->paginate = [
            'contain' => ['Lessons'],
        ];

        $checkStudent = 0;

        if ($this->userIdentification() == "Student"){
            $questions = $this->paginate($this->Questions->find('all', array('conditions'=>array('Questions.lesson_id'=>$id))));
            $checkStudent = 1;
        }else{
            $questions = $this->paginate($this->Questions);
        }
        $lessonTable = TableRegistry::get('Lessons');
        $topic = $lessonTable->find('all')->where(['id'=>$id])->first()->topic;


        $this->set(compact('questions', 'checkStudent', 'topic'));
    }

    /**
     * View method
     *
     * @param string|null $id Question id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $question = $this->Questions->get($id, [
            'contain' => ['Lessons', 'AnswerSheets'],
        ]);
        $studentTable = TableRegistry::get('Students');

        $this->set(compact('question', 'studentTable'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($id = null)
    {
        $this->viewActive();
        $question = $this->Questions->newEmptyEntity();

        $lessonTable = TableRegistry::get('Lessons');
        $lesson = $lessonTable->find('all')->where(['id'=>$id])->first();
        $lesson_topic= $lesson->topic;
        if ($this->request->is('post')) {
            $question = $this->Questions->patchEntity($question, $this->request->getData());
            $question->lesson_id = $id;
            if ($this->Questions->save($question)) {
                $this->Flash->success(__('The question has been saved.'));

                return $this->redirect(['controller'=>'lessons', 'action' => 'view', $question->lesson_id]);
            }
            $this->Flash->error(__('The question could not be saved. Please, try again.'));
        }
        $lessons = $this->Questions->Lessons->find('list', ['limit' => 200])->all();
        $this->set(compact('question', 'lessons', 'lesson_topic'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Question id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $question = $this->Questions->get($id, [
            'contain' => [],
        ]);

        $lessonTable = TableRegistry::get('Lessons');
        $lesson = $lessonTable->find('all')->where(['id'=>$question->lesson_id])->first();
        $lesson_topic= $lesson->topic;

        if ($this->request->is(['patch', 'post', 'put'])) {
            $question = $this->Questions->patchEntity($question, $this->request->getData());
            if ($this->Questions->save($question)) {
                $this->Flash->success(__('The question has been saved.'));

                return $this->redirect(['controller' => 'lessons', 'action' => 'view', $question->lesson_id]);
            }
            $this->Flash->error(__('The question could not be saved. Please, try again.'));
        }
        $this->set(compact('question', 'lesson_topic'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Question id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $question = $this->Questions->get($id);
        if ($this->Questions->delete($question)) {
            $this->Flash->success(__('The question has been deleted.'));
        } else {
            $this->Flash->error(__('The question could not be deleted. Please, try again.'));
        }

        return $this->redirect(['controller' => 'lessons', 'action' => 'view', $question->lesson_id]);
    }

}
