<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;

/**
 * Enrolments Controller
 *
 * @property \App\Model\Table\EnrolmentsTable $Enrolments
 * @method \App\Model\Entity\Enrolment[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class EnrolmentsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewActive();
        $this->paginate = [
            'contain' => ['Students', 'Courses'],
        ];
        $checkStudent = 0;

        if ($this->userIdentification() == "Student"){
            $enrolments = $this->paginate($this->Enrolments->find('all', array('conditions'=>array('Students.id'=>$this->getStudentID()))));
            $checkStudent = 1;
        }else{
            $enrolments = $this->paginate($this->Enrolments);
        }
        $this->set(compact('enrolments', 'checkStudent'));

    }

    /**
     * View method
     *
     * @param string|null $id Enrolment id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $enrolment = $this->Enrolments->get($id, [
            'contain' => ['Students', 'Courses'],
        ]);

        $this->set(compact('enrolment'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($courseID = null)
    {
        $this->viewActive();
        $enrolment = $this->Enrolments->newEmptyEntity();

        if ($this->request->is('post')) {
            $enrolment = $this->Enrolments->patchEntity($enrolment, $this->request->getData());
            $enrolment->course_id = $courseID;
            if ($this->Enrolments->save($enrolment)) {
                $this->Flash->success(__('The enrolment has been saved.'));
                return $this->redirect(['controller'=> 'courses', 'action' => 'view', $courseID]);
            }
            $this->Flash->error(__('The enrolment could not be saved. Please, try again.'));
        }
        $students = $this->Enrolments->Students->find('list', ['limit' => 200])->all();
//      $courses = $this->Enrolments->Courses->find('list', ['limit' => 200])->all();
        $courseTable = TableRegistry::get('Courses');
        $courseName = $courseTable->find('all')->where(['id'=>$courseID])->first()->name;

        $this->set(compact('enrolment', 'students', 'courseName'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Enrolment id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $enrolment = $this->Enrolments->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $enrolment = $this->Enrolments->patchEntity($enrolment, $this->request->getData());
            if ($this->Enrolments->save($enrolment)) {
                $this->Flash->success(__('The enrolment has been saved.'));

                return $this->redirect(['controller'=> 'courses', 'action' => 'view', $enrolment->course_id]);
            }
            $this->Flash->error(__('The enrolment could not be saved. Please, try again.'));
        }

        $studentTable = TableRegistry::get('Students');
        $studentName = $studentTable->find('all')->where(['id'=>$enrolment->student_id])->first()->firstname . ' ' .$studentTable->find('all')->where(['id'=>$enrolment->student_id])->first()->lastname;


        $courseTable = TableRegistry::get('Courses');
        $courseName = $courseTable->find('all')->where(['id'=>$enrolment->course_id])->first()->name;


        $this->set(compact('enrolment', 'studentName', 'courseName'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Enrolment id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $enrolment = $this->Enrolments->get($id);
        if ($this->Enrolments->delete($enrolment)) {
            $this->Flash->success(__('The enrolment has been deleted.'));
        } else {
            $this->Flash->error(__('The enrolment could not be deleted. Please, try again.'));
        }

        return $this->redirect(['controller'=> 'courses', 'action' => 'view', $enrolment->course_id]);
    }
}
