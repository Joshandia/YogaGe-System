<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;

/**
 * Certifications Controller
 *
 * @property \App\Model\Table\CertificationsTable $Certifications
 * @method \App\Model\Entity\Certification[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CertificationsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewActive();
        $this->paginate = [
            'contain' => ['Courses'],
        ];
        $certifications = $this->paginate($this->Certifications);

        $this->set(compact('certifications'));
    }

    /**
     * View method
     *
     * @param string|null $id Certification id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $certification = $this->Certifications->get($id, [
            'contain' => ['Courses', 'Awards'],
        ]);
        $studentTable = TableRegistry::get('Students');
        $this->set(compact('certification', 'studentTable'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($courseID = null)
    {
        $this->viewActive();
        $certification = $this->Certifications->newEmptyEntity();
        if ($this->request->is('post')) {
            $certification = $this->Certifications->patchEntity($certification, $this->request->getData());
            $certification->course_id = $courseID;

            if ($this->Certifications->save($certification)) {
                $this->Flash->success(__('The certification has been saved.'));

                return $this->redirect(['controller' =>'courses' ,'action' => 'view', $courseID]);
            }
            $this->Flash->error(__('The certification could not be saved. Please, try again.'));
        }

        $courseTable = TableRegistry::get('Courses');
        $courseName = $courseTable->find('all')->where(['id'=>$courseID])->first()->name;
        $this->set(compact('certification', 'courseName'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Certification id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $certification = $this->Certifications->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $certification = $this->Certifications->patchEntity($certification, $this->request->getData());
            if ($this->Certifications->save($certification)) {
                $this->Flash->success(__('The certification has been saved.'));

                return $this->redirect(['controller'=> 'courses', 'action' => 'view', $certification->course_id]);
            }
            $this->Flash->error(__('The certification could not be saved. Please, try again.'));
        }
        $courses = $this->Certifications->Courses->find('list', ['limit' => 200])->all();

        $courseTable = TableRegistry::get('Courses');
        $courseName = $courseTable->find('all')->where(['id'=>$certification->course_id])->first()->name;

        $this->set(compact('certification', 'courses', 'courseName'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Certification id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $certification = $this->Certifications->get($id);
        if ($this->Certifications->delete($certification)) {
            $this->Flash->success(__('The certification has been deleted.'));
        } else {
            $this->Flash->error(__('The certification could not be deleted. Please, try again.'));
        }

        return $this->redirect(['controller'=> 'courses', 'action' => 'view', $certification->course_id]);
    }

}
