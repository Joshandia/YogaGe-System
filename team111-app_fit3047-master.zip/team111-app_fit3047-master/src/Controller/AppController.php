<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Controller\Controller;

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link https://book.cakephp.org/4/en/controllers.html#the-app-controller
 */
class AppController extends Controller
{
    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('FormProtection');`
     *
     * @return void
     */
    public function initialize(): void
    {
        parent::initialize();
        $this->loadComponent('Flash');

        $this->loadComponent('Authentication.Authentication');
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Authorization.Authorization');

        /*
         * Enable the following component for recommended CakePHP form protection settings.
         * see https://book.cakephp.org/4/en/controllers/components/form-protection.html
         */
        //$this->loadComponent('FormProtection');

    }
    // in src/Controller/AppController.php
    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
        // for all controllers in our application, make index and view
        // actions public, skipping the authentication check
        $this->Authentication->addUnauthenticatedActions(['forgetpassword', 'resetpassword','add','login']);
    }

    public function viewActive()
    {
        $this->Authorization->skipAuthorization();
        $result = $this->Authentication->getResult();

        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            // 1. read the user identity
            $user = $this->Authentication->getIdentity();

            // 2. get user role
            $user_type = $user->type;

            // 3 find out where the user should go after login
            if ($user_type == "Admin" )
            {
                $this->viewBuilder()->setLayout('admin');
                //do something
            } else if ($user_type == 'Student') {
                $this->viewBuilder()->setLayout('student');
                // go somewhere else
            }
        }
    }

    public function userIdentification()
    {
        $result = $this->Authentication->getResult();
        $this->Authentication->addUnauthenticatedActions(['logout']);
        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            // 1. read the user identity
            $user = $this->Authentication->getIdentity();

            // 2. get user role
            return $user->type;
        }
        return null;
    }

    public function getStudentID()
    {
        $result = $this->Authentication->getResult();

        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            // 1. read the user identity
            $user = $this->Authentication->getIdentity();

            if ($user->type == 'Student') {
                return $user->id;
            }
        }
        return null;
    }

    public function studentLimit()
    {
        $this->Authorization->skipAuthorization();
        $result = $this->Authentication->getResult();

        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            // 1. read the user identity
            $user = $this->Authentication->getIdentity();

            // 2. get user role
            $user_type = $user->type;

            // 3 find out where the user should go after login
            if ($user_type == "Admin" )
            {
                $this->Authorization->skipAuthorization();
            }
        }
    }
}
