<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;

/**
 * AnswerSheets Controller
 *
 * @property \App\Model\Table\AnswerSheetsTable $AnswerSheets
 * @method \App\Model\Entity\AnswerSheet[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AnswerSheetsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewActive();
        $this->paginate = [
            'contain' => ['Students', 'Questions'],
        ];

        $checkStudent = 0;
        $lessonTable = TableRegistry::get('Lessons');
        $courseTable = TableRegistry::get('Courses');
        $studentTable = TableRegistry::get('Students');
        $questionTable = TableRegistry::get('Questions');
        if ($this->userIdentification() == "Student"){
            $answerSheets = $this->paginate($this->AnswerSheets->find('all', array('conditions'=>array('Students.id'=>$this->getStudentID()))));
            $checkStudent = 1;
        }else{
            $answerSheets = $this->paginate($this->AnswerSheets);
        }

        $this->set(compact('answerSheets', 'checkStudent', 'lessonTable', 'courseTable', 'studentTable', 'questionTable'));
    }

    /**
     * View method
     *
     * @param string|null $id Answer Sheet id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $answerSheet = $this->AnswerSheets->get($id, [
            'contain' => ['Students', 'Questions'],
        ]);

        $this->set(compact('answerSheet'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->viewActive();
        $answerSheet = $this->AnswerSheets->newEmptyEntity();
        if ($this->request->is('post')) {
            $answerSheet = $this->AnswerSheets->patchEntity($answerSheet, $this->request->getData());
            if ($this->AnswerSheets->save($answerSheet)) {
                $this->Flash->success(__('The answer sheet has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The answer sheet could not be saved. Please, try again.'));
        }
        $students = $this->AnswerSheets->Students->find('list', ['limit' => 200])->all();
        $questions = $this->AnswerSheets->Questions->find('list', ['limit' => 200])->all();
        $this->set(compact('answerSheet', 'students', 'questions'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Answer Sheet id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $answerSheet = $this->AnswerSheets->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $answerSheet = $this->AnswerSheets->patchEntity($answerSheet, $this->request->getData());
            if ($this->AnswerSheets->save($answerSheet)) {
                $this->Flash->success(__('The answer sheet has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The answer sheet could not be saved. Please, try again.'));
        }
        $students = $this->AnswerSheets->Students->find('list', ['limit' => 200])->all();
        $questions = $this->AnswerSheets->Questions->find('list', ['limit' => 200])->all();
        $this->set(compact('answerSheet', 'students', 'questions'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Answer Sheet id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $answerSheet = $this->AnswerSheets->get($id);
        if ($this->AnswerSheets->delete($answerSheet)) {
            $this->Flash->success(__('The answer sheet has been deleted.'));
        } else {
            $this->Flash->error(__('The answer sheet could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    /**
     * Answer method
     *
     * @param string|null $id Answer Sheet id.
     * @property \App\Model\Table\StudentsTable $Students
     * @method \App\Model\Entity\Student[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function answer($question_id = null, $question = null)
    {
        $this->viewActive();

        $answerSheet = $this->AnswerSheets->newEmptyEntity();

        if ($this->request->is('post')) {
            $answerSheet = $this->AnswerSheets->patchEntity($answerSheet, $this->request->getData());
            $answerSheet->question_id = $question_id;
            $answerSheet->student_id = $this->getStudentID();

            if ($this->AnswerSheets->save($answerSheet)) {
                $this->Flash->success(__('The answer sheet has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('111The answer sheet could not be saved. Please, try again.'));
        }
        $students = $this->AnswerSheets->Students->find('list', ['limit' => 200])->all();
        $questions = $this->AnswerSheets->Questions->find('list', ['limit' => 200])->all();

        $this->set(compact('answerSheet', 'students', 'questions', 'question'));
    }


    public function pass($id = null){
        $this->Authorization->skipAuthorization();
        $answerSheet = $this->AnswerSheets->get($id);
        $answerSheet->status = "Pass";
        $this->AnswerSheets->save($answerSheet);
        return $this->redirect(['controller'=>'questions','action' => 'view',$this->AnswerSheets->get($id)->question_id]);
    }


    public function fail($id = null){
        $this->Authorization->skipAuthorization();
        $answerSheet = $this->AnswerSheets->get($id);
        $answerSheet->status = "Fail";
        $this->AnswerSheets->save($answerSheet);
        return $this->redirect(['controller'=>'questions','action' => 'view',$this->AnswerSheets->get($id)->question_id]);
    }
}
