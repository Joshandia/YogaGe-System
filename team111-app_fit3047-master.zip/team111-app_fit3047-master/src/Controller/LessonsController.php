<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;

/**
 * Lessons Controller
 *
 * @property \App\Model\Table\LessonsTable $Lessons
 * @method \App\Model\Entity\Lesson[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class LessonsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewActive();
        $this->paginate = [
            'contain' => ['Courses'],
        ];

        $lessons = $this->paginate($this->Lessons);

        $this->set(compact('lessons'));
    }

    /**
     * View method
     *
     * @param string|null $id Lesson id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $lesson = $this->Lessons->get($id, [
            'contain' => ['Courses', 'Questions'],
        ]);

        $checkStudent = 0;
        if ($this->userIdentification() == "Student"){
            $checkStudent = 1;
        }

        $this->set(compact('lesson', 'checkStudent'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($courseID = null)
    {
        $this->viewActive();
        $lesson = $this->Lessons->newEmptyEntity();
        if ($this->request->is('post')) {
            $lesson = $this->Lessons->patchEntity($lesson, $this->request->getData());
            $lesson->course_id = $courseID;

            if ($this->Lessons->save($lesson)) {
                $this->Flash->success(__('The lesson has been saved.'));

                return $this->redirect(['controller' => 'courses', 'action' => 'view', $courseID]);
            }
            $this->Flash->error(__('The lesson could not be saved. Please, try again.'));
        }
        $courseTable = TableRegistry::get('Courses');
        $courseName = $courseTable->find('all')->where(['id'=>$courseID])->first()->name;
        $this->set(compact('lesson', 'courseName'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Lesson id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $lesson = $this->Lessons->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lesson = $this->Lessons->patchEntity($lesson, $this->request->getData());
            if ($this->Lessons->save($lesson)) {
                $this->Flash->success(__('The lesson has been saved.'));

                return $this->redirect(['controller'=> 'courses', 'action' => 'view', $lesson->course_id]);
            }
            $this->Flash->error(__('The lesson could not be saved. Please, try again.'));
        }
        $courseTable = TableRegistry::get('Courses');
        $courseName = $courseTable->find('all')->where(['id'=>$lesson->course_id])->first()->name;
        $this->set(compact('lesson', 'courseName'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Lesson id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $lesson = $this->Lessons->get($id);
        if ($this->Lessons->delete($lesson)) {
            $this->Flash->success(__('The lesson has been deleted.'));
        } else {
            $this->Flash->error(__('The lesson could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

}
