<?php
declare(strict_types=1);

namespace App\Controller;

use App\View\AppView;
use Cake\Mailer\Mailer;
use Cake\Mailer\TransportFactory;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Utility\Security;
use Cake\ORM\TableRegistry;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
    /*public function forget(){
        if($this->request->is('post')){
            $myemail = $this->request->getData('email');
            $mytoken = "a";
            $user = $this->Users->findOrCreate(['email'=>$myemail]);
            $user->token = $mytoken;
            if($this->Users->save($user)){
                $this->Flash->success("Reset password link has been to your email ('.$myemail.'), Please open your inbox");
                $link = AppView::$Html->link('Reset Password','/users/reset/' . $mytoken);
                $mailer = new Mailer('default');
                $mailer->setFrom(['dhee0009@student.monash.edu' => 'Daddy'])
                    ->setTo($myemail)
                    ->setSubject('Please confirm your reset password')
                    ->deliver("Hello ".$myemail."<br/>Please click link below to reset your password<br/><a href='$link'></a>");
            }
        }
    }*/

    public function forgetpassword()
    {
        $this->Authorization->skipAuthorization();
        $this->viewBuilder()->setLayout('ajax');
        if ($this->request->is('post')) {
            $email = $this->request->getData('email');
            $token = Security::hash(Security::randomBytes(25));

            $userTable = TableRegistry::get('Users');
            if ($email == NULL) {
                $this->Flash->error(__('Please insert your email address'));
            }
            if	($user = $userTable->find('all')->where(['email'=>$email])->first()) {
                $user->token = $token;
                if ($userTable->save($user)){
                    /*$mailer = new Mailer('default');
                    $mailer->setFrom([ 'dhee0009@student.monash.edu'=> 'daddy'])
                        ->setTo($email)
                        ->setEmailFormat('html')
                        ->setSubject('Forgot Password Request')
                        ->deliver('Hello<br/>Please click link below to reset your password<br/><br/><a href="http://localhost/joecakeproject/users/resetpassword/'.$token.'">Reset Password</a>');*/

                    $mailer = new Mailer();
                    $mailer
                        ->setEmailFormat('html')
                        ->setTo($email)
                        ->setFrom('dhee0009@student.monash.edu')
                        ->setSubject('Forgot Password Request')
                        ->viewBuilder();

                    $mailer->deliver('Hello<br/>Please click link below to reset your password<br/><br/><a href="http://localhost/joecakeproject/users/resetpassword/'.$token.'">Reset Password</a>');

                }
                $this->Flash->success('Reset password link has been sent to your email ('.$email.'), please check your email');
            }
            if	($total = $userTable->find('all')->where(['email'=>$email])->count()==0) {
                $this->Flash->error(__('Email is not registered in system'));
            }
        }
    }

    public function resetpassword($token)
    {
        $this->Authorization->skipAuthorization();
        $this->viewBuilder()->setLayout('ajax');
        if($this->request->is('post')){
            $newPass = $this->request->getData('password');

            $userTable = TableRegistry::get('Users');
            $user = $userTable->find('all')->where(['token'=>$token])->first();
            $user->password = $newPass;
            if ($userTable->save($user)) {
                $this->Flash->success('Password successfully reset. Please login using your new password');
                return $this->redirect(['action'=>'login']);
            }
        }
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->studentLimit();
        $this->viewBuilder()->setLayout('admin');
        $users = $this->paginate($this->Users->find('all', array('conditions'=>array('Users.type'=>'Admin'))));
        $this->set(compact('users'));
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewActive();
        $user = $this->Users->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('user'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->Authorization->skipAuthorization();
        $this->viewBuilder()->setLayout('ajax');
        $user = $this->Users->newEmptyEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));
                return $this->redirect(['action' => 'login']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again...'));
        }
        $this->set(compact('user'));
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewActive();
        $user = $this->Users->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewActive();
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['controller'=>'users', 'action' => 'index']);
    }


    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
        // Configure the login action to not require authentication, preventing
        // the infinite redirect loop issue
        $this->Authentication->addUnauthenticatedActions(['login', 'add']);
    }

    public function login()
    {
        $this->Authorization->skipAuthorization();
        $this->viewBuilder()->setLayout('ajax');
        $this->request->allowMethod(['get', 'post']);
        $result = $this->Authentication->getResult();

        // display error if user submitted and authentication failed
        if ($this->request->is('post') && !($result->isValid())) {
            $this->Flash->error(__('Invalid username or password'));
        }
        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            // TODO: ]

            // 1. read the user identity
            $user = $this->Authentication->getIdentity();

            // 2. get user role
            $user_type = $user->type;

            // 3 find out where the user should go after login
            if ($user_type == "Admin" )
            {
                $this->viewBuilder()->setLayout('admin');
                $redirect = $this->request->getQuery('redirect', [
                    'controller' => 'Pages',
                    'action' => 'admin',
                ]);

                //do something
            } else if ($user_type == 'Student') {
                $this->viewBuilder()->setLayout('student');
                $redirect = $this->request->getQuery('redirect', [
                    'controller' => 'Pages',
                    'action' => 'student',
                ]);
                // go somewhere else
            }

            // redirect to /articles after login success
            return $this->redirect($redirect);
        }

    }

    // in src/Controller/UsersController.php
    public function logout()
    {
        $this->Authorization->skipAuthorization();
        $this->viewBuilder()->setLayout('ajax');
        $this->request->allowMethod(['get', 'post']);
        $result = $this->Authentication->getResult();
        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            $this->Authentication->logout();
            $redirect = $this->request->getQuery('redirect', [
                'controller' => 'Users',
                'action' => 'login',
            ]

            );
            return $this->redirect($redirect);
        }
    }



    public function viewActive()
    {
        $this->Authorization->skipAuthorization();
        $result = $this->Authentication->getResult();

        // regardless of POST or GET, redirect if user is logged in
        if ($result && $result->isValid()) {
            // 1. read the user identity
            $user = $this->Authentication->getIdentity();

            // 2. get user role
            $user_type = $user->type;

            // 3 find out where the user should go after login
            if ($user_type == "Admin" )
            {
                $this->viewBuilder()->setLayout('admin');
                //do something
            } else if ($user_type == 'Student') {
                $this->viewBuilder()->setLayout('student');
               // go somewhere else
            }
        }
    }
}
